plot_overview <- function(plot_name, data)
{
  mycols=c("green", "yellow", "red")
  pdf(plot_name)
  plot    (data$x, data$y, lwd=4, pch=19, col="green", ylim=c(min(data$hdi_min), max(data$hdi_max)), xlab="", ylab="material failure rate [%]", main="")
  segments(data$x, data$hdi_min, data$x, data$hdi_max, col="gray", lwd=3)
  for(i in 1:length(data$x))
  {points  (data$x[i], data$y[i], lwd=4, pch=19, col=mycols[data$tcol[i]+1])}
  dev.off()
}
# -------------------------------------------
# Histogram with fits and QQ plots ...
# -------------------------------------------
check_results <- function(InPosterior, InTruncData, InTransData)
{
  for(blr3 in 1:InTransData$stan_data$Num_BLR3)
  {
    ML_mat_mu   <- estimate_mode(InPosterior$BLR3_mu [,blr3])
    ML_mat_var  <- estimate_mode(InPosterior$BLR3_var[,blr3])

    this_blr3tm     <- which( blr3 == InTransData$stan_data$map_BLR3TM_2_BLR3)
    cat("this_blr3tm = ", this_blr3tm, "\n")
    for( tm in 1:length(this_blr3tm))
    {
      this_data_index    <- which( this_blr3tm[tm] == InTruncData$stan_data$blr3tm_Index)
      this_data          <- InTruncData$stan_data$Measurements[this_data_index]
      
      this_data_index    <- which( this_blr3tm[tm] == InTransData$stan_data$blr3tm_Index)
      this_data_notTrunc <- InTransData$stan_data$Measurements[this_data_index] 

      this_num_data          <- length(this_data)
      this_num_data_notTrunc <- length(this_data_notTrunc)
      
      this_R3TM <- InTruncData$stan_data$map_BLR3TM_2_R3TM[this_blr3tm[tm]]
      this_TM   <- InTruncData$stan_data$map_R3TM_2_TM[this_R3TM]
      ML_TM_mu  <- estimate_mode(InPosterior$R3TM_mu [,this_R3TM])
      ML_TM_var <- estimate_mode(InPosterior$R3TM_var[,this_R3TM])
      
      this_mu <-      ML_mat_mu + ML_TM_mu 
      this_sd <- sqrt(ML_mat_var + ML_TM_var)
      
      cat("ATE = ",tm," :: this_mu = ", this_mu, "\n")
      cat("ATE = ",tm," :: this_sd = ", this_sd, "\n")
      
      plot_name  <- paste(PIP$OutPath, "Fit_performace_BLR3_",blr3,"_TM_", this_TM,".pdf", sep="")
      par(mfrow=c(3,2))
      pdf(plot_name)
      par(mfrow=c(3,2))
      # ----- histogram - TRUNCATED
      hist_x  <- seq( InTruncData$stan_data$trunc_min[this_blr3tm[tm]], InTruncData$stan_data$trunc_max[this_blr3tm[tm]], (InTruncData$stan_data$trunc_max[this_blr3tm[tm]]- InTruncData$stan_data$trunc_min[this_blr3tm[tm]])/100)
      ML_hist <- dtnorm(hist_x, this_mu, this_sd, lower=InTruncData$stan_data$trunc_min[this_blr3tm[tm]], upper=InTruncData$stan_data$trunc_max[this_blr3tm[tm]])
      hist(this_data, freq = FALSE, main="hist trunc data")
      lines(hist_x, ML_hist, col="blue", lwd=2)
      
      # ----- histogram - NOT -  TRUNCATED
      hist_x  <- seq( min(this_data_notTrunc), max(this_data_notTrunc), (max(this_data_notTrunc) - min(this_data_notTrunc))/100)
      ML_hist <- dnorm(hist_x, this_mu, this_sd)
      hist(this_data_notTrunc, freq = FALSE, main="hist all data")
      lines(hist_x, ML_hist, col="blue", lwd=2)
      
      #--------------------------------------------------------------------------------
      # ----- (-)INF - QQ-truncated-plot
      #--------------------------------------------------------------------------------
      data_x      <- sort(this_data)
      data_CDF    <- seq(1, this_num_data, 1)/this_num_data
      ML_CDF      <- ptnorm(data_x, mean=this_mu, sd=this_sd, lower=InTruncData$stan_data$trunc_min[this_blr3tm[tm]], upper=InTruncData$stan_data$trunc_max[this_blr3tm[tm]])
      # ----- CDF-plot
      #plot (data_x, data_CDF, main="CDF")
      #lines(data_x, ML_CDF, col="blue", lwd=3)
      
      this_dia <- c( max(c(min(c(log10(data_CDF), log10(ML_CDF))), -5)), max(c(log10(ML_CDF), log10(data_CDF))))
      plot(this_dia, this_dia, lwd=2, type='l', xlab="data_CDF", ylab="CDF", main="(-)INF-QQ trunc")
      lines(log10(data_CDF), log10(ML_CDF), col="blue", lwd=2)
      
      # ----- (-)INF-QQ- NOT-truncated-plot
      data_x      <- sort(this_data_notTrunc)
      data_CDF    <- seq(1, this_num_data_notTrunc, 1)/this_num_data_notTrunc
      ML_CDF      <- pnorm(data_x, mean=this_mu, sd=this_sd)
      
      this_dia <- c( max(c(min(c(log10(data_CDF), log10(ML_CDF))), -5)), max(c(log10(ML_CDF), log10(data_CDF))))
      plot(this_dia, this_dia, lwd=2, type='l', xlab="data_CDF", ylab="CDF", main="(-)INF-QQ")
      lines(log10(data_CDF), log10(ML_CDF), col="blue", lwd=2)
  
      #--------------------------------------------------------------------------------
      # ----- (+)INF - QQ-truncated-plot
      #--------------------------------------------------------------------------------
      data_x      <- sort(this_data, decreasing=TRUE)
      data_CDF    <- seq(1, this_num_data, 1)/this_num_data
      ML_CDF      <- 1-ptnorm(data_x, mean=this_mu, sd=this_sd, lower=InTruncData$stan_data$trunc_min[this_blr3tm[tm]], upper=InTruncData$stan_data$trunc_max[this_blr3tm[tm]])
      this_dia <- c( max(c(min(c(log10(data_CDF), log10(ML_CDF))), -5)), max(c(log10(ML_CDF), log10(data_CDF))))
      plot(this_dia, this_dia, lwd=2, type='l', xlab="data_CDF", ylab="CDF", main="(+)INF-QQ trunc")
      lines(log10(data_CDF), log10(ML_CDF), col="blue", lwd=2)
      
      # ----- (+)INF-QQ- NOT-truncated-plot
      data_x      <- sort(this_data_notTrunc, decreasing=TRUE)
      data_CDF    <- seq(1, this_num_data_notTrunc, 1)/this_num_data_notTrunc
      ML_CDF      <- 1-pnorm(data_x, mean=this_mu, sd=this_sd)
      
      this_dia <- c( max(c(min(c(log10(data_CDF), log10(ML_CDF))), -5)), max(c(log10(ML_CDF), log10(data_CDF))))
      plot(this_dia, this_dia, lwd=2, type='l', xlab="data_CDF", ylab="CDF", main="(+)INF-QQ")
      lines(log10(data_CDF), log10(ML_CDF), col="blue", lwd=2)
  
      dev.off()
    }
    par(mfrow=c(1,1))
  }
}

# -------------------------------------------
# Histogram with fits and QQ plots ...
# -------------------------------------------
