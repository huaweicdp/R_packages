source("post_process.R")

test_calc_failures_with_integrals <- function()
{
  stan_data <- list(Num_BLR3 = 1, Num_R3TM = 1, Acc_min = -1, Acc_max=1, map_BLR3TM_2_BLR3=rbind(1), map_BLR3TM_2_R3=rbind(1), map_BLR3TM_2_R3TM = rbind(1), map_BLR3_2_R3=rbind(1))
  mat_mu    <- 0
  mat_var   <- 1
  TM_mu     <- 0 
  TM_var    <- 0.2
  
  Num_ran     <- 100000
  ran_mat     <- rnorm(Num_ran, mat_mu, sqrt(mat_var))
  
  I_Mat_OUT   <- which(ran_mat < stan_data$Acc_min | ran_mat > stan_data$Acc_max)
  I_Mat_IN    <- which(ran_mat > stan_data$Acc_min & ran_mat < stan_data$Acc_max)
  ran_tm      <- rnorm(Num_ran, TM_mu, sqrt(TM_var))
  
  meas        <- ran_mat + ran_tm
  I_TM_F_OUT  <- which((stan_data$Acc_min > meas | stan_data$Acc_max < meas) & (ran_mat > stan_data$Acc_min & ran_mat < stan_data$Acc_max) )
  I_TM_F_IN   <- which((stan_data$Acc_min < meas & stan_data$Acc_max > meas) & (ran_mat < stan_data$Acc_min | ran_mat > stan_data$Acc_max) )
  
  cat(" MAT theta     = ", length(I_Mat_OUT) /Num_ran , "\n")
  cat(" TM  false OUT = ", length(I_TM_F_OUT)/Num_ran , "\n")
  cat(" TM  falce IN  = ", length(I_TM_F_IN) /Num_ran , "\n")
  
  sample_size <- 100
  post <- list( BLR3_mu  = cbind(rnorm(sample_size, mat_mu , 0.01)),
                BLR3_var = cbind(rnorm(sample_size, mat_var, 0.01)),
                R3TM_mu  = cbind(rnorm(sample_size, TM_mu  , 0.01)),
                R3TM_var = cbind(rnorm(sample_size, TM_var , 0.01)))
  a <- calc_failures_with_integrals(post, list(stan_data=stan_data))
  
}

calc_SYN <- function(SYN, InData)
{
  # NORMALISE PIP PARAMETERS
  OUT_SYN <- list ( BLR3_mu   = array(dim=InData$stan_data$Num_BLR3),
                    BLR3_var  = array(dim=InData$stan_data$Num_BLR3),
                    R3TM_mu   = array(dim=InData$stan_data$Num_R3TM),
                    R3TM_var  = array(dim=InData$stan_data$Num_R3TM))
  
  for(blr3 in 1:InData$stan_data$Num_BLR3)
  {
    this_a <- InData$normalise$a[InData$stan_data$map_BLR3_2_R3[blr3]]
    this_b <- InData$normalise$b[InData$stan_data$map_BLR3_2_R3[blr3]]
    OUT_SYN$BLR3_mu [blr3] <- this_a * SYN$BLR3_mu[blr3] + this_b
    OUT_SYN$BLR3_sd [blr3] <- this_a * SYN$BLR3_sd[blr3]  
  }  

  for(r3tm in 1:InData$stan_data$Num_R3TM)
  {
    this_a <- InData$normalise$a[InData$stan_data$map_R3TM_2_R3[r3tm]]
    this_b <- InData$normalise$b[InData$stan_data$map_R3TM_2_R3[r3tm]]
    OUT_SYN$R3TM_mu [r3tm] <- this_a*SYN$R3TM_mu [r3tm]
    OUT_SYN$R3TM_sd [r3tm] <- this_a*SYN$R3TM_sd [r3tm]   
  }  
  
  ### SIMULATE FAILING RATES
  Sim_sample             <- 100000
  BLR3_theta             <- array(0, dim=InData$stan_data$Num_BLR3)
  R3TM_false_defect      <- array(0, dim=InData$stan_data$Num_R3TM)
  R3TM_false_correct     <- array(0, dim=InData$stan_data$Num_R3TM)
  R3TM_false_defect_cnt  <- array(0, dim=InData$stan_data$Num_R3TM)
  R3TM_false_correct_cnt <- array(0, dim=InData$stan_data$Num_R3TM)
  
  for(blr3 in 1:InData$stan_data$Num_BLR3)
  {
    cat("blr3 = ", blr3, "\n")
    this_r3          <- InData$stan_data$map_BLR3_2_R3[blr3]
    this_data        <- rnorm(Sim_sample, OUT_SYN$BLR3_mu[blr3], OUT_SYN$BLR3_sd[blr3])
    these_mat_out    <- this_data[which( this_data                         < InData$stan_data$Acc_min[this_r3] | InData$stan_data$Acc_max[this_r3] < this_data   )] 
    these_mat_in     <- this_data[which( InData$stan_data$Acc_min[this_r3] < this_data                         & this_data                < InData$stan_data$Acc_max[this_r3] )]
    
    BLR3_theta[blr3] <- length(these_mat_out)  / Sim_sample
    these_R3TM       <- which(InData$stan_data$map_BLR3_2_R3[blr3] == InData$stan_data$map_R3TM_2_R3)
    cat("these_R3TM = ", these_R3TM, "\n")
    for(r3tm in these_R3TM)
    {
      cat("r3tm = ", r3tm, "\n")
      this_error_in      <- rnorm(length(these_mat_in ), OUT_SYN$R3TM_mu[r3tm], OUT_SYN$R3TM_sd[r3tm])
      this_error_out     <- rnorm(length(these_mat_out), OUT_SYN$R3TM_mu[r3tm], OUT_SYN$R3TM_sd[r3tm])
      
      if(r3tm == 1)
        cat("R3TM_false_defect     [r3tm] = ",R3TM_false_defect     [r3tm],"\n")
      R3TM_false_defect     [r3tm] <- R3TM_false_defect     [r3tm] + length( which( (these_mat_in + this_error_in) < InData$stan_data$Acc_min[this_r3]  | InData$stan_data$Acc_max[this_r3]  < (these_mat_in + this_error_in) ))
      R3TM_false_defect_cnt [r3tm] <- R3TM_false_defect_cnt [r3tm] + Sim_sample

      if(r3tm == 1)
        cat("R3TM_false_defect     [r3tm] = ",R3TM_false_defect     [r3tm],"   R3TM_false_defect_cnt [r3tm]", R3TM_false_defect_cnt [r3tm],"\n")
      R3TM_false_correct    [r3tm] <- R3TM_false_correct    [r3tm] + length( which( InData$stan_data$Acc_min[this_r3]  < (these_mat_out + this_error_out) & (these_mat_out + this_error_out) < InData$stan_data$Acc_max[this_r3] ))
      R3TM_false_correct_cnt[r3tm] <- R3TM_false_correct_cnt[r3tm] + Sim_sample
    }
  }
  
  for(r3tm in 1:InData$stan_data$Num_R3TM)
  {
    R3TM_false_defect [r3tm] <- R3TM_false_defect [r3tm] / R3TM_false_defect_cnt [r3tm] 
    R3TM_false_correct[r3tm] <- R3TM_false_correct[r3tm] / R3TM_false_correct_cnt[r3tm] 
  }    
  
  return(list(BLR3_mu = OUT_SYN$BLR3_mu, BLR3_sd = OUT_SYN$BLR3_sd, R3TM_mu = OUT_SYN$R3TM_mu, R3TM_sd = OUT_SYN$R3TM_sd,
              BLR3_theta = BLR3_theta, R3TM_false_defect=R3TM_false_defect, R3TM_false_correct=R3TM_false_correct))  
}