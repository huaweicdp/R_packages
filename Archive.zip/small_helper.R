# -------------------------------------------
# smallhelper.R
# -------------------------------------------
HDI <- function( sampleVec , credMass=0.95 ) {
  # Computes highest density interval from a sample of representative values,
  #   estimated as shortest credible interval.
  # Arguments:
  #   sampleVec
  #     is a vector of representative values from a probability distribution.
  #   credMass
  #     is a scalar between 0 and 1, indicating the mass within the credible
  #     interval that is to be estimated.
  # Value:
  #   HDIlim is a vector containing the limits of the HDI
  sortedPts = sort( sampleVec )
  ciIdxInc = floor( credMass * length( sortedPts ) )
  nCIs = length( sortedPts ) - ciIdxInc
  ciWidth = rep( 0 , nCIs )
  for ( i in 1:nCIs ) {
    ciWidth[ i ] = sortedPts[ i + ciIdxInc ] - sortedPts[ i ]
  }
  HDImin = sortedPts[ which.min( ciWidth ) ]
  HDImax = sortedPts[ which.min( ciWidth ) + ciIdxInc ]
  HDIlim = c( HDImin , HDImax )
  return( HDIlim )
}

# -----------------------------------------------------
# estimate mode
# ------------------------------------------------------
estimate_mode <- function(x) {
      
  d <- density(x)
  if(length(x) == length(which(x==0)) )
  {
    return(0)
  }else{
    return(d$x[which.max(d$y)])
  }
}

myrotate <- function(data, deg=-0.25*pi)
{
  rx <- data[,1]*cos(deg) - data[,2]*sin(deg)
  ry <- data[,1]*sin(deg) + data[,2]*cos(deg)
  return(list(x=rx, y=ry)) 
}
