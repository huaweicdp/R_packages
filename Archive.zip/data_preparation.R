create_quick_data <- function(SYN)
{
  blr3  <- 1
  numdata <- SYN$Num_B*SYN$Num_L_per_B*SYN$Num_R3_per_L*SYN$Num_TM_per_R3*PIP$Num_Data_per_BLR3TM
  RawData  <-numeric(0)
  for(batch in 1:SYN$Num_B)
  {
    for(lot in 1:SYN$Num_L_per_B)
    {
      r3tm <- 1
      for(r3 in 1:SYN$Num_R3_per_L)
      {
        for(tm in 1:SYN$Num_TM_per_R3)
        {
          
          tmp_mat    <- rnorm(SYN$Num_Data_per_BLR3TM, SYN$BLR3_mu[blr3], SYN$BLR3_sd[blr3])
          this_err   <- rnorm(SYN$Num_Data_per_BLR3TM, SYN$R3TM_mu[r3tm], SYN$R3TM_sd[r3tm])
          
          meas                               <- tmp_mat + this_err

          tmp_mat_ng <- rbinom(1, SYN$Num_Data_per_BLR3TM, SYN$BLR3_ng_rate[blr3])
          tmp_tm_ng  <- rbinom(1, SYN$Num_Data_per_BLR3TM, SYN$R3TM_ng_rate[r3tm])
          if((tmp_mat_ng+tmp_tm_ng) > 0)
          {
            meas_mat_ng <- runif(tmp_mat_ng, SYN$Unif_min, SYN$Unif_max)
            meas_tm_ng  <- runif(tmp_tm_ng , SYN$Unif_min, SYN$Unif_max)
            meas[1:(tmp_mat_ng+tmp_tm_ng)]     <- c(meas_mat_ng, meas_tm_ng)
          }
          
          cat("create_quick_data :: created ", (tmp_mat_ng+tmp_tm_ng), " outliers -  tm = ", tm, "\n")
          this_b   <- paste("BATCH_"       , batch, sep="")
          this_l   <- paste("LOT_"         , lot  , sep="")
          this_r3  <- paste("Test_L03_"    , r3   , sep="")
          this_tm  <- paste("TM_"          , tm   , sep="")
          myrow    <- cbind(rep(this_b  , times=SYN$Num_Data_per_BLR3TM),
                            rep(this_l  , times=SYN$Num_Data_per_BLR3TM),
                            rep(this_r3 , times=SYN$Num_Data_per_BLR3TM),
                            rep(this_tm , times=SYN$Num_Data_per_BLR3TM),
                            meas)
          
          RawData   <- rbind(RawData, myrow)
          r3tm      <- r3tm + 1
        }
        blr3  <- blr3 + 1
      }
    }
  }
  this_R3 <- unique(RawData[,3])
  Acc_Table   <- data.table(HANA_R3=this_R3, Acc_min=rep(PIP$Acc_min, times=length(this_R3)), Acc_max=rep(PIP$Acc_max, times=length(this_R3)) ) 
  
  return(list(Data_Table=RawData, Acc_Table=Acc_Table))
}     

filter_low_numbers <- function(InPutData)
{
  InData          <- InPutData$Data_Table
  NumData         <- dim(InData)[1]
  UNIQ_BLRR3TM    <- rbind(unique(InData[,1:4]))
  Num_Comb        <- dim(UNIQ_BLRR3TM)[1]
  cat("filter_low_numbers :: found  -- ", Num_Comb, " -- BLR3TM combinations and -- ",NumData," -- datapoints in the datatables!\n")
  counts          <- array(0, dim=Num_Comb)
  for(i in 1:Num_Comb)
  {
    tmp_indicies <- which( apply(InData[,1:4], 1, FUN = function(x)identical(x, UNIQ_BLRR3TM[i, ]) ) )
    counts[i]    <- length(tmp_indicies)
  }
  
  index                  <- which(counts < PIP$Min_number_Data)
  Num_filter_BLR3TM      <- length(index)
  FILTERED_BLR3TM <- rbind(c(UNIQ_BLRR3TM[index,], counts[index]))
  
  if(Num_filter_BLR3TM > 0)
  {
    cat("filter_low_numbers :: start filter of  -- ", Num_filter_BLR3TM, " -- BLR3TM combinations in the datatables!\n")
    num_data_filtered <- 0
    for(i in 1:Num_filter_BLR3TM)
    {
      tmp_indicies        <- which( apply(InData[, 1:4], 1, FUN = function(x)identical(x, FILTERED_BLR3TM[i, 1:4 ]) ) )
      num_data_filtered   <- num_data_filtered + length(tmp_indicies)
      if(length(tmp_indicies) > 0)
      {InData<- rbind(InData[(-1)*tmp_indicies, ])}
    }
    
    cat("filter_low_numbers :: filtered ", num_data_filtered, " data out \n")
    NumData         <- dim(InData)[1]
    UNIQ_BLRR3TM    <- rbind(unique(InData[,1:4]))
    Num_Comb        <- dim(UNIQ_BLRR3TM)[1]
    cat("filter_low_numbers :: found  -- ", Num_Comb, " -- BLR3TM combinations and -- ",NumData," -- datapoints in the datatables!\n")
    cat("filter_low_numbers :: -------------------------------------------------------------------\n")
  }
  InPutData$Data_Table    <- InData
  return(list(FILTERED_BLR3TM=FILTERED_BLR3TM, InData=InPutData))
}



#### Table structures
#### R3TM_Table   --    1:R3TM_Index    2:HANA R3     3: HANA TM   4: Num_BL           5: Num_BL       6: R3TM_Num_TM    7: map_R3TM_2_R3
#### B_Table      --    1:B_Index       2:HANA BATCH
#### BL_Table     --    1:BL_Index      2:HANA BATCH  3: HANA LOT  4: map_BL_2_B-Index
#### BLR3_Table   --    1:BLR3_Index    2:HANA BATCH  3: HANA LOT  4: HANA R3     
#### BLR3TM_Table --    1:BLR3TM_Index  2:HANA BATCH  3: HANA LOT  4: HANA R3          5: HANA TM      6: map_BLR3TM_2_BLR3  7:map_BLR3TM_2_R3TM
transform_2_internal <- function (InPutData)
{
  InData    <- InPutData$InData$Data_Table
  Acc_Table <- InPutData$InData$Acc_Table
  #### ------------------------------------------------
  ####            OTHER HEADER TABLES 
  #### ------------------------------------------------
  R3_Table         <- unique(InData[,3])
  Num_R3           <- length(R3_Table)
  R3_Table         <- data.table(R3_Index=seq(1, Num_R3, 1), HANA_R3=R3_Table)  

  Acc_min   <- array(dim=Num_R3)
  Acc_max   <- array(dim=Num_R3)
  
  for( r3 in 1:Num_R3)
  {
    r3_index <- which(Acc_Table$HANA_R3[r3] == R3_Table$HANA_R3)
    if(is.numeric(Acc_Table$Acc_min[r3]))
    {Acc_min[r3_index] = Acc_Table$Acc_min[r3]}
    else
    {Acc_min[r3_index] = -Inf}
    
    if(is.numeric(Acc_Table$Acc_max[r3]))
    {Acc_max[r3_index] = Acc_Table$Acc_max[r3]}
    else
    {Acc_max[r3_index] = +Inf}
  }
  #### ------------------------------------------------
  ####            Testmachine HEADER TABLES 
  #### ------------------------------------------------
  TM_Table         <- unique(InData[,4])
  Num_TM           <- length(TM_Table)
  TM_Table         <- data.table(TM_Index=seq(1, Num_TM, 1), HANA_TM=TM_Table)  
  
  ### --- R3TM TABLE
  R3TM_Table       <- rbind(unique(InData[, 3:4]))
  Num_R3TM         <- dim(R3TM_Table)[1]
  R3TM_Num_BL      <- array(0, dim=Num_R3TM)
  R3TM_Num_TM      <- array(0, dim=Num_R3TM)
  map_R3TM_2_R3    <- array(0, dim=Num_R3TM)
  map_R3TM_2_TM    <- array(0, dim=Num_R3TM)

  for(r3tm in 1:Num_R3TM)
  {
    map_R3TM_2_R3[r3tm] <- R3_Table$R3_Index[which( R3_Table$HANA_R3 == R3TM_Table[r3tm, 1])]
    map_R3TM_2_TM[r3tm] <- TM_Table$TM_Index[which( TM_Table$HANA_TM == R3TM_Table[r3tm, 2])]
    bl_indicies         <- which( apply( InData[, c(3:4)], 1, FUN = function(x)identical(x, R3TM_Table[r3tm, 1:2]) ) )
    diff_bl             <- unique(InData[bl_indicies,1:2])
    R3TM_Num_BL[r3tm]   <- dim(diff_bl)[1]
    
    diff_blr3 <- cbind(diff_bl, rep(R3_Table$HANA_R3[map_R3TM_2_R3[r3tm]]))
    all_tm <- numeric(0)
    for(i in 1:R3TM_Num_BL[r3tm])
    {
      bl_indicies    <- which( apply( InData[, 1:3], 1, FUN = function(x)identical(x, diff_blr3[i, 1:3]) ) ) 
      all_tm         <- c(all_tm, InData[bl_indicies, 4]) 
    }
    R3TM_Num_TM[r3tm]   <- length(unique(all_tm))
  }
  R3TM_Table     <- data.table(R3TM_Index = seq(1, Num_R3TM, 1), HANA_R3=R3TM_Table[,1], HANA_TM=R3TM_Table[,2], R3TM_Num_BL=R3TM_Num_BL, R3TM_Num_TM=R3TM_Num_TM)  
  
  #### ------------------------------------------------
  ####            MATERIAL HEADER TABLES 
  #### ------------------------------------------------
  #### CREATE -- B-TABLE -- 
  B_Table          <- (unique(InData[,1]))
  Num_B            <- length(B_Table)
  B_Table          <- data.table(B_Index=seq(1, Num_B, 1), HANA_B=B_Table)

  #### CREATE -- BR3-TABLE -- 
  BR3_Table        <- rbind(unique(InData[,c(1,3)]))
  Num_BR3          <- dim(BR3_Table)[1]
  map_BR3_2_B      <- array(0, dim=Num_BR3)
  map_BR3_2_R3     <- array(0, dim=Num_BR3)
  for(br3 in 1:Num_BR3)
  {
    map_BR3_2_B [br3]  <- B_Table$B_Index  [which(B_Table$HANA_B   == BR3_Table[ br3,1])]
    map_BR3_2_R3[br3]  <- R3_Table$R3_Index[which(R3_Table$HANA_R3 == BR3_Table[ br3,2])]
  }
  BR3_Table         <- data.table(BR3_Index=seq(1, Num_BR3, 1), HANA_B=BR3_Table[,1], HANA_R3=BR3_Table[,2], map_BR3_2_B=map_BR3_2_B)
  
  #### CREATE -- BL-TABLE -- 
  BL_Table         <- rbind(unique(InData[,1:2]))
  Num_BL           <- dim(BL_Table)[1]
  map_BL_2_B       <- array(0, dim=Num_BL)
  for(bl in 1:Num_BL)
    {map_BL_2_B[bl]  <- B_Table$B_Index[which(B_Table$HANA_B == BL_Table[ bl,1])]}
  BL_Table         <- data.table(BL_Index=seq(1, Num_BL, 1), HANA_B=BL_Table[,1], HANA_L=BL_Table[,2], map_BL_2_B=map_BL_2_B)
  
  #### CREATE -- BLR3-TABLE -- 
  BLR3_Table       <- rbind(unique(InData[,1:3]))
  BLR3_Table       <- cbind(BLR3_Table[,1], BLR3_Table[,2], BLR3_Table[,3])
  Num_BLR3         <- dim(BLR3_Table)[1]
  map_BLR3_2_R3    <- array(0, dim=Num_BLR3)
  map_BLR3_2_BL    <- array(0, dim=Num_BLR3)
  map_BLR3_2_BR3   <- array(0, dim=Num_BLR3)
  for(blr3 in 1:Num_BLR3)
  {
    map_BLR3_2_R3 [blr3] <- R3_Table$R3_Index  [ which(      cbind(R3_Table$HANA_R3) == BLR3_Table[ blr3, 3]) ]
    map_BLR3_2_BL [blr3] <- BL_Table$BL_Index  [ which(apply(cbind(BL_Table$HANA_B , BL_Table$HANA_L  ), 1, FUN = function(x)identical(x, BLR3_Table  [blr3  , 1:2]) ) )]
    map_BLR3_2_BR3[blr3] <- BR3_Table$BR3_Index[ which(apply(cbind(BR3_Table$HANA_B, BR3_Table$HANA_R3), 1, FUN = function(x)identical(x, BLR3_Table  [blr3  , c(1,3)]) ) )]
  }
  BLR3_Table       <- data.table(BLR3_Index=seq(1, Num_BLR3, 1),  HANA_B=BLR3_Table[,1], HANA_L=BLR3_Table[,2], HANA_R3=BLR3_Table[,3], map_BLR3_2_R3=map_BLR3_2_R3)
  
  #### CREATE -- BLR3TM TABLE -- 
  BLR3TM_Table       <- rbind(unique(InData[,1:4]))
  BLR3TM_Table       <- cbind(BLR3TM_Table[, 1], BLR3TM_Table[, 2], BLR3TM_Table[, 3], BLR3TM_Table[, 4])
  Num_BLR3TM         <- dim(BLR3TM_Table)[1]
  map_BLR3TM_2_R3    <- array(0, dim=Num_BLR3TM)
  map_BLR3TM_2_B     <- array(0, dim=Num_BLR3TM)
  map_BLR3TM_2_BL    <- array(0, dim=Num_BLR3TM)
  map_BLR3TM_2_BLR3  <- array(0, dim=Num_BLR3TM)
  map_BLR3TM_2_R3TM  <- array(0, dim=Num_BLR3TM)
  for(blr3tm in 1:Num_BLR3TM)
  {
    map_BLR3TM_2_B   [blr3tm] <- B_Table$B_Index      [ which(B_Table$HANA_B   == BLR3TM_Table[blr3tm, 1])]
    map_BLR3TM_2_R3  [blr3tm] <- R3_Table$R3_Index    [ which(R3_Table$HANA_R3 == BLR3TM_Table[blr3tm, 3])]
    map_BLR3TM_2_BL  [blr3tm] <- BL_Table$BL_Index    [ which(apply(cbind(BL_Table$HANA_B   , BL_Table$HANA_L   )                   , 1, FUN = function(x)identical(x, BLR3TM_Table[blr3tm, 1:2]) ) )]
    map_BLR3TM_2_BLR3[blr3tm] <- BLR3_Table$BLR3_Index[ which(apply(cbind(BLR3_Table$HANA_B , BLR3_Table$HANA_L, BLR3_Table$HANA_R3), 1, FUN = function(x)identical(x, BLR3TM_Table[blr3tm, 1:3]) ) )]
    map_BLR3TM_2_R3TM[blr3tm] <- R3TM_Table$R3TM_Index[ which(apply(cbind(R3TM_Table$HANA_R3, R3TM_Table$HANA_TM)                   , 1, FUN = function(x)identical(x, BLR3TM_Table[blr3tm, 3:4]) ) )]
  }
  BLR3TM_Table     <- data.table(BLR3TM_Index= seq(1, Num_BLR3TM, 1),
                                 HANA_B      = BLR3TM_Table[,1],
                                 HANA_L      = BLR3TM_Table[,2],
                                 HANA_R3     = BLR3TM_Table[,3],
                                 HANA_TM     = BLR3TM_Table[,4],
                                 map_BLR3TM_2_BLR3 = map_BLR3TM_2_BLR3,
                                 map_BLR3TM_2_R3TM = map_BLR3TM_2_R3TM)
  
  #### ------------------------------------------------
  ####            MEASUREMENT TABLE 
  #### ------------------------------------------------
  Num_Data           <- dim(InData)[1]
  blr3tm_Index       <- array(0, dim=Num_Data)
  for(blr3tm in 1:Num_BLR3TM)
  {
    this_data <- c(BLR3TM_Table$HANA_B[blr3tm], BLR3TM_Table$HANA_L[blr3tm], BLR3TM_Table$HANA_R3[blr3tm], BLR3TM_Table$HANA_TM[blr3tm] )
    tmp_index <- which(apply( cbind(InData[, 1], InData[ ,2], InData[ ,3], InData[ ,4]), 1, FUN = function(x)identical(x, this_data ) ) )
    blr3tm_Index[tmp_index] <- blr3tm
  }
  
  stan_data <- list(
    Acc_min           = Acc_min,
    Acc_max           = Acc_max,    
    Num_B             = Num_B,
    Num_BR3           = Num_BR3,
    Num_BL            = Num_BL,
    Num_R3            = Num_R3,
    Num_TM            = Num_TM,
    Num_R3TM          = Num_R3TM,
    Num_BLR3          = Num_BLR3,
    Num_BLR3TM        = Num_BLR3TM,
    R3TM_Num_TM       = R3TM_Num_TM,
    R3TM_Num_BL       = R3TM_Num_BL,
    map_R3TM_2_R3     = map_R3TM_2_R3,
    map_R3TM_2_TM     = map_R3TM_2_TM,
    map_BLR3TM_2_R3   = map_BLR3TM_2_R3,
    map_BLR3TM_2_BL   = map_BLR3TM_2_BL,
    map_BLR3TM_2_R3TM = map_BLR3TM_2_R3TM,
    map_BLR3TM_2_BLR3 = map_BLR3TM_2_BLR3,
    map_BLR3_2_R3     = map_BLR3_2_R3,
    map_BLR3_2_BL     = map_BLR3_2_BL,
    map_BLR3_2_BR3    = map_BLR3_2_BR3,
    map_BR3_2_B       = map_BR3_2_B,
    map_BR3_2_R3      = map_BR3_2_R3,
    map_BL_2_B        = map_BL_2_B,
    Num_Data          = Num_Data,
    blr3tm_Index      = blr3tm_Index,
    Measurements      = as.double(InData[,5])
  )
  Out_Tables <- list(  
    B_Table      = B_Table,
    BL_Table     = BL_Table,
    BLR3_Table   = BLR3_Table,
    BLR3TM_Table = BLR3TM_Table,
    R3TM_Table   = R3TM_Table,
    R3           = R3_Table,
    TM_Table     = TM_Table)
  OutData <- list(stan_data    = stan_data, Out_Tables = Out_Tables)
  return(OutData)
}

#### BLR3TM_Table --    add --  8: tunrcation_min 9: truncation_max
truncate_data <- function(InData)
{
  stan_data        <- InData$stan_data
  trunc_min        <- array(0, dim=stan_data$Num_BLR3TM)
  trunc_max        <- array(0, dim=stan_data$Num_BLR3TM)
#  InData$Truncated <- numeric(0)
  New_Measurements <- numeric(0)
  for(blr3tm in 1:stan_data$Num_BLR3TM)
  {
    tmp_indicies          <- which( stan_data$blr3tm_Index == blr3tm)
    myHDI                 <- HDI(stan_data$Measurements[ tmp_indicies ], credMass = PIP$TRUNC_percent)
    trunc_min[blr3tm]     <- myHDI[1]
    trunc_max[blr3tm]     <- myHDI[2]
    
#    tmp_indicies_out      <- which(stan_data$Measurements[tmp_indicies] < myHDI[1]  | myHDI[2] < stan_data$Measurements[tmp_indicies])
#    if(length(tmp_indicies_out) >0)
#       {InData$Truncated <- rbind(InData$Truncated, cbind(rep(blr3tm, times=length(tmp_indicies_out)), stan_data$Measurements[tmp_indicies[tmp_indicies_out]] ) )}

    tmp_indicies_in       <- which( myHDI[1] < stan_data$Measurements[tmp_indicies]  & stan_data$Measurements[tmp_indicies] < myHDI[2] )
    if(length(tmp_indicies_in) >0)
      {New_Measurements <- rbind(New_Measurements, cbind(rep(blr3tm, times=length(tmp_indicies_in)), stan_data$Measurements[tmp_indicies[tmp_indicies_in]] ) )}
    
  }
  stan_data$Num_Data     <- dim(New_Measurements)[1]
  stan_data$blr3tm_Index <- New_Measurements[,1]
  stan_data$Measurements <- New_Measurements[,2]
  stan_data$trunc_min    <- trunc_min
  stan_data$trunc_max    <- trunc_max
  InData$stan_data       <- stan_data
  return(InData)
}

normalize_data <- function(InData)
{
  ## y = a*x+b   : 
  ## mu(y)       = a * mu(x) + b
  ## sigma(y)    = a * sigma(x)
  a          <- array(1, dim=InData$stan_data$Num_R3)
  b          <- array(0, dim=InData$stan_data$Num_R3)
  for(r3 in 1:InData$stan_data$Num_R3)
  {
    blr3tm_indicies  <- which(InData$stan_data$map_BLR3TM_2_R3 == r3)
    data_indicies    <- numeric(0)
    for(i in 1:length(blr3tm_indicies))
    {
      this_indicies    <- which(blr3tm_indicies[i] == InData$stan_data$blr3tm_Index)
      data_indicies    <- c(data_indicies, this_indicies)
    }
    this_Measure     <- InData$stan_data$Measurements[data_indicies]
    
    a[r3]= (+1.0)/sd(this_Measure)
    b[r3]= (-1.0) * a[r3] * mean(this_Measure)
    
    InData$stan_data$Measurements[data_indicies] <- a[r3] * this_Measure                   + b[r3]
    InData$stan_data$Acc_min  [r3]               <- a[r3] * InData$stan_data$Acc_min  [r3] + b[r3]
    InData$stan_data$Acc_max  [r3]               <- a[r3] * InData$stan_data$Acc_max  [r3] + b[r3]
          
#    stan_data$trunc_min[blr3tm_indicies]           <- a[r3] * stan_data$trunc_min [blr3tm_indicies] + b[r3]
#    stan_data$trunc_max[blr3tm_indicies]           <- a[r3] * stan_data$trunc_max [blr3tm_indicies] + b[r3]
    
  } ### end blr3_i
  InData$normalise <- list(a=a, b=b)
  return(InData) 
}

denormalize_posterior <- function(InPosterior, InData)
{
  for(blr3_i in 1:InData$stan_data$Num_BLR3)
  {
    this_a <- InData$normalise$a[InData$stan_data$map_BLR3_2_R3[blr3_i]]
    this_b <- InData$normalise$b[InData$stan_data$map_BLR3_2_R3[blr3_i]]
    InPosterior$BLR3_mu [ ,blr3_i] <- (InPosterior$BLR3_mu [ ,blr3_i] - this_b) / this_a
    InPosterior$BLR3_var[ ,blr3_i] <-  InPosterior$BLR3_var[ ,blr3_i] / this_a  #/ this_a
    
  }
  
  for(r3tm in 1:InData$stan_data$Num_R3TM)
  {
    this_a <- InData$normalise$a[InData$stan_data$map_R3TM_2_R3[r3tm]]
    this_b <- InData$normalise$b[InData$stan_data$map_R3TM_2_R3[r3tm]]
    InPosterior$R3TM_mu  [,r3tm] <-  InPosterior$R3TM_mu [,r3tm] / this_a
    InPosterior$R3TM_var [,r3tm] <-  InPosterior$R3TM_var[,r3tm] / this_a #/ this_a
  }
  return(InPosterior)
}

