calc_trafficlights <- function(PIP, data, critical_rate)
{
  traffic_light <- 0
  Num_data      <- length(data)
  tmp_i         <- which(data >= critical_rate)
  if(length(tmp_i)/Num_data >= PIP$prob_yellow)
  {traffic_light <- 1}
  if(length(tmp_i)/Num_data >= PIP$prob_red)
  {traffic_light <- 2}
  return(traffic_light)
}
#-------------------------------------------------------------------------------
## OUTDATA Structure:
## BLR3_OUT :
##  1 : BLR3-Index
##  2 : HANA - Batch
##  3 : HANA - Lot
##  4 : HANA - R2
##  5 : Material : Traffic Light - 0=green, 1=yellow, 2=red
##  6 : Material : MaxLikel. failure rate
##  7 : Material : minimal-Error
##  8 : Material : maximal-Error
##  9 : NotGauss : Traffic Light - 0=green, 1=yellow, 2=red
## 10 : NotGauss : MaxLikel. failure rate
## 11 : NotGauss : minimal-Error
## 12 : NotGauss : maximal-Error
## ---------------------------
## BL_OUT :
##  1 : BL-Index
##  2 : HANA - Batch
##  3 : HANA - Lot
##  4 : Material : Traffic Light - 0=green, 1=yellow, 2=red
##  5 : Material : MaxLikel. failure rate
##  6 : Material : minimal-Error
##  7 : Material : maximal-Error
##  8 : NotGauss : Traffic Light - 0=green, 1=yellow, 2=red
##  9 : NotGauss : MaxLikel. failure rate
## 10 : NotGauss : minimal-Error
## 11 : NotGauss : maximal-Error
## ---------------------------
## B_OUT :
##  1 : B-Index
##  2 : HANA - Batch
##  3 : Material : Traffic Light - 0=green, 1=yellow, 2=red
##  4 : Material : MaxLikel. failure rate
##  5 : Material : minimal-Error
##  6 : Material : maximal-Error
##  7 : NotGauss : Traffic Light - 0=green, 1=yellow, 2=red
##  8 : NotGauss : MaxLikel. failure rate
##  9 : NotGauss : minimal-Error
## 10 : NotGauss : maximal-Error
## ---------------------------
## Supp_OUT :
##  1 : Material : Traffic Light - 0=green, 1=yellow, 2=red
##  2 : Material : MaxLikel. failure rate
##  3 : Material : minimal-Error
##  4 : Material : maximal-Error
##  8 : NotGauss : Traffic Light - 0=green, 1=yellow, 2=red
##  9 : NotGauss : MaxLikel. failure rate
## 10 : NotGauss : minimal-Error
## 11 : NotGauss : maximal-Error
## ---------------------------
## R3TM_OUT :
##  1  : R3TM-Index
##  2  : HANA - R3
##  3  : HANA - TM
##  4  : Traffic Light false defect rate - 0=green, 1=yellow, 2=red
##  5  : MaxLikel. false defect rate
##  6  : minimal-Error false defect
##  7  : maximal-Error false defect
##  8  : Traffic Lightfalse correct rate  - 0=green, 1=yellow, 2=red
##  9  : MaxLikel. false correct rate
##  10 : minimal-Error false correct
##  11 : maximal-Error false correct
##  12 : NotGauss : Traffic Light  - 0=green, 1=yellow, 2=red
##  13 : NotGauss : MaxLikel. rate
##  14 : NotGauss : minimal-Error 
##  15 : NotGauss : maximal-Error 
## ---------------------------
## TM_OUT :
##  1 : TM-Index
##  2 : HANA - TM
##  3  : Traffic Light false defect rate - 0=green, 1=yellow, 2=red
##  4  : MaxLikel. false defect rate
##  5  : minimal-Error false defect
##  6  : maximal-Error false defect
##  7  : Traffic Lightfalse correct rate  - 0=green, 1=yellow, 2=red
##  8  : MaxLikel. false correct rate
##  9  : minimal-Error false correct
##  10 : maximal-Error false correct
##  11 : NotGauss : Traffic Light    - 0=green, 1=yellow, 2=red
##  12 : NotGauss : MaxLikel. rate
##  13 : NotGauss : minimal-Error 
##  14 : NotGauss : maximal-Error 
## ---------------------------

generate_Output<-function(InPosterior_fails, InPosterior_outlier, InData, out_str)
{
  BOOL_PLOT <- "TRUE"
  stan_data<- InData$stan_data
  ###---------------------------------------------------------------
  ### Generate MATERIAL Output
  ###---------------------------------------------------------------
  ### BLR3 - level
  ### ----------------  
  BLR3_OUT <- InData$Out_Tables$BLR3_Table[,1:4]   
  t_lights <- array(0, dim=stan_data$Num_BLR3)
  y        <- array(0, dim=c(stan_data$Num_BLR3,3))
  for(i in 1:stan_data$Num_BLR3)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$BLR3_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$BLR3_theta[ , i] )
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$BLR3_theta[,i], PIP$Critical_fail_material)
  }
  BLR3_OUT <- cbind(BLR3_OUT, TLight_matFail=t_lights, Mode_matFail=y[,1], Err_Min_matFail=y[,2], Err_Max_matFail=y[,3])
  ## outlier
  t_lights <- array(0, dim=stan_data$Num_BLR3)
  y        <- array(0, dim=c(stan_data$Num_BLR3,3))
  for(i in 1:stan_data$Num_BLR3)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_outlier$BLR3_ng_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_outlier$BLR3_ng_theta[ , i] )
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_outlier$BLR3_ng_theta[,i], PIP$Critical_fail_material_outlier)
  }
  BLR3_OUT <- cbind(BLR3_OUT, TLight_outlier=t_lights, Mode_outlier=y[,1], Err_Min_outlier=y[,2], Err_Max_outlier=y[,3])
  
  if(BOOL_PLOT)
  {
    plot_overview(paste(PIP$OutPath, out_str, "BLR3_mat.pdf", sep=""), 
                  list(x=BLR3_OUT$BLR3_Index, y=BLR3_OUT$Mode_matFail, hdi_min=BLR3_OUT$Err_Min_matFail, hdi_max=BLR3_OUT$Err_Max_matFail, tcol=BLR3_OUT$TLight_matFail))
  
    plot_overview(paste(PIP$OutPath, out_str, "BLR3_outlier.pdf", sep=""), 
                  list(x=BLR3_OUT$BLR3_Index, y=BLR3_OUT$Mode_outlier, hdi_min=BLR3_OUT$Err_Min_outlier, hdi_max=BLR3_OUT$Err_Max_outlier, tcol=BLR3_OUT$TLight_outlier))
  }  
  
  ### ----------------  
  ### BL - level
  ### ----------------  
  BL_OUT   <-InData$Out_Tables$BL_Table[,1:3]   
  t_lights <- array(0, dim=stan_data$Num_BL)
  y        <- array(0, dim=c(stan_data$Num_BL,3))
  for(i in 1:stan_data$Num_BL)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$BL_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$BL_theta[ , i] )
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$BL_theta[,i], PIP$Critical_fail_material)
  }
  BL_OUT <- cbind(BL_OUT, TLight_matFail=t_lights, Mode_matFail=y[,1], Err_Min_matFail=y[,2], Err_Max_matFail=y[,3])
  #outlier
  t_lights <- array(0, dim=stan_data$Num_BL)
  y        <- array(0, dim=c(stan_data$Num_BL,3))
  for(i in 1:stan_data$Num_BL)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_outlier$BL_ng_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_outlier$BL_ng_theta[ , i] )
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_outlier$BL_ng_theta[,i], PIP$Critical_fail_material_outlier)
  }
  BL_OUT <- cbind(BL_OUT, TLight_outlier=t_lights, Mode_outlier=y[,1], Err_Min_outlier=y[,2], Err_Max_outlier=y[,3])

  if(BOOL_PLOT)
  {
    plot_overview(paste(PIP$OutPath, out_str, "BL_mat.pdf", sep=""), list(x=BL_OUT$BL_Index, y=BL_OUT$Mode_matFail, hdi_min=BL_OUT$Err_Min_matFail, hdi_max=BL_OUT$Err_Max_matFail, tcol=BL_OUT$TLight_matFail))
    plot_overview(paste(PIP$OutPath, out_str, "BL_outlier.pdf", sep=""), list(x=BL_OUT$BL_Index, y=BL_OUT$Mode_outlier, hdi_min=BL_OUT$Err_Min_outlier, hdi_max=BL_OUT$Err_Max_outlier, tcol=BL_OUT$TLight_outlier))
  }  
  ### ----------------  
  ### B - level
  ### ----------------  
  B_OUT    <-InData$Out_Tables$B_Table[,1:2]   
  t_lights <- array(0, dim=stan_data$Num_B)
  y        <- array(0, dim=c(stan_data$Num_B,3))
  for(i in 1:stan_data$Num_B)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$B_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$B_theta[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$B_theta[,i], PIP$Critical_fail_material)
  }
  B_OUT <- cbind(B_OUT, TLight_matFail=t_lights, Mode_matFail=y[,1], Err_Min_matFail=y[,2], Err_Max_matFail=y[,3])
  #outlier
  t_lights <- array(0, dim=stan_data$Num_B)
  y        <- array(0, dim=c(stan_data$Num_B,3))
  for(i in 1:stan_data$Num_B)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_outlier$B_ng_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_outlier$B_ng_theta[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_outlier$B_ng_theta[,i], PIP$Critical_fail_material_outlier)
  }
  B_OUT <- cbind(B_OUT, TLight_outlier=t_lights, Mode_outlier=y[,1], Err_Min_outlier=y[,2], Err_Max_outlier=y[,3])

  if(BOOL_PLOT)
  {
    plot_overview(paste(PIP$OutPath, out_str, "B_mat.pdf", sep=""), list(x=B_OUT$B_Index, y=B_OUT$Mode_matFail, hdi_min=B_OUT$Err_Min_matFail, hdi_max=B_OUT$Err_Max_matFail, tcol=B_OUT$TLight_matFail))
    plot_overview(paste(PIP$OutPath, out_str, "B_outlier.pdf", sep=""), list(x=B_OUT$B_Index, y=B_OUT$Mode_outlier, hdi_min=B_OUT$Err_Min_outlier, hdi_max=B_OUT$Err_Max_outlier, tcol=B_OUT$TLight_outlier))
  }  
  ### ----------------  
  ### Supp - level
  ### ----------------  
  y        <- array(0, dim=3)
  y[1]     <- 100*estimate_mode(InPosterior_fails$Supp_theta)
  y[2:3]   <- HDI (100*InPosterior_fails$Supp_theta)
  t_lights <- calc_trafficlights(PIP, InPosterior_fails$Supp_theta[], PIP$Critical_fail_material)

  y_o        <- array(0, dim=3)
  y_o[1]     <- 100*estimate_mode(InPosterior_outlier$Supp_ng_theta)
  y_o[2:3]   <- HDI (100*InPosterior_outlier$Supp_ng_theta)
  t_lights_o <- calc_trafficlights(PIP, InPosterior_outlier$Supp_ng_theta[], PIP$Critical_fail_material_outlier)
  Supp_OUT <- list(TLight_matFail=t_lights, Mode_matFail=y[1], Err_Min_matFail=y[2], Err_Max_matFail=y[3], TLight_outlier=t_lights, Mode_outlier=y[1], Err_Min_outlier=y[2], Err_Max_outlier=y[3])
  
  ### ----------------  
  ### R3TM - level
  ### ----------------  
  R3TM_OUT <- InData$Out_Tables$R3TM_Table[,1:3]   
  t_lights <- array(0, dim=stan_data$Num_R3TM)
  y        <- array(0, dim=c(stan_data$Num_R3TM,3))
  for(i in 1:stan_data$Num_R3TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$R3TM_false_defect[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$R3TM_false_defect[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$R3TM_false_defect[,i], PIP$Critical_fail_TM)
  }
  R3TM_OUT <- cbind(R3TM_OUT, TLight_false_defect=t_lights, Mode_false_defect=y[,1], Err_Min__false_defect=y[,2], Err_Max_false_defect=y[,3])

  for(i in 1:stan_data$Num_R3TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$R3TM_false_correct[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$R3TM_false_correct[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$R3TM_false_correct[,i], PIP$Critical_fail_TM)
  }
  R3TM_OUT <- cbind(R3TM_OUT, TLight_false_correct=t_lights, Mode_false_correct=y[,1], Err_Min_false_correct=y[,2], Err_Max_false_correct=y[,3])
  
  for(i in 1:stan_data$Num_R3TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_outlier$R3TM_ng_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_outlier$R3TM_ng_theta[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_outlier$R3TM_ng_theta[,i], PIP$Critical_fail_TM_outlier)
  }
  R3TM_OUT <- cbind(R3TM_OUT, TLight_outlier=t_lights, Mode_outlier=y[,1], Err_Min_outlier=y[,2], Err_Max_outlier=y[,3])
  
  if(BOOL_PLOT)
  {
    
    plot_overview(paste(PIP$OutPath, out_str, "R3TM_outlier.pdf", sep=""), list(x       = R3TM_OUT$R3TM_Index,
                                                                                      y       = R3TM_OUT$Mode_outlier,
                                                                                      hdi_min = R3TM_OUT$Err_Min_outlier,
                                                                                      hdi_max = R3TM_OUT$Err_Max_outlier,
                                                                                      tcol    = R3TM_OUT$TLight_outlier))
    
    
    plot_overview(paste(PIP$OutPath, out_str, "R3TM_false_correct.pdf", sep=""), list(x       = R3TM_OUT$R3TM_Index,
                                                                                      y       = R3TM_OUT$Mode_false_correct,
                                                                                      hdi_min = R3TM_OUT$Err_Min_false_correct,
                                                                                      hdi_max = R3TM_OUT$Err_Max_false_correct,
                                                                                      tcol    = R3TM_OUT$TLight_false_correct))
    
    plot_overview(paste(PIP$OutPath, out_str, "R3TM_false_defect.pdf", sep=""), list(x       = R3TM_OUT$R3TM_Index,
                                                                                     y       = R3TM_OUT$Mode_false_defect,
                                                                                     hdi_min = R3TM_OUT$Err_Min__false_defect,
                                                                                     hdi_max = R3TM_OUT$Err_Max_false_defect,
                                                                                     tcol    = R3TM_OUT$TLight_false_defect))
  }    
  
  
  ### ----------------  
  ### TM - level
  ### ----------------  
  TM_OUT    <-InData$Out_Tables$TM_Table[,1:2]   
  t_lights <- array(0, dim=stan_data$Num_TM)
  y        <- array(0, dim=c(stan_data$Num_TM,3))
  for(i in 1:stan_data$Num_TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$TM_false_defect[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$TM_false_defect[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$TM_false_defect[,i], PIP$Critical_fail_TM)
  }
  TM_OUT <- cbind(TM_OUT, TLight_false_defect=t_lights, Mode_false_defect=y[,1], Err_Min_false_defect=y[,2], Err_Max_false_defect=y[,3])
  
  for(i in 1:stan_data$Num_TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_fails$TM_false_correct[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_fails$TM_false_correct[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_fails$TM_false_correct[,i], PIP$Critical_fail_TM)
  }
  TM_OUT <- cbind(TM_OUT, TLight_false_correct=t_lights, Mode_false_correct=y[,1], Err_Min_false_correct=y[,2], Err_Max_false_correct=y[,3])
  
  for(i in 1:stan_data$Num_TM)
  {
    y[i, 1]     <- 100*estimate_mode(InPosterior_outlier$TM_ng_theta[ , i])
    y[i, 2:3]   <- HDI (100*InPosterior_outlier$TM_ng_theta[ , i])
    t_lights[i] <- calc_trafficlights(PIP, InPosterior_outlier$TM_ng_theta[,i], PIP$Critical_fail_TM)
  }
  TM_OUT <- cbind(TM_OUT, TLight_outlier=t_lights, Mode_outlier=y[,1], Err_Min_outlier=y[,2], Err_Max_outlier=y[,3])
  
  if(BOOL_PLOT)
  {
    
    plot_overview(paste(PIP$OutPath, out_str, "TM_outlier.pdf", sep="")       , list(x      = TM_OUT$TM_Index,
                                                                                    y       = TM_OUT$Mode_outlier,
                                                                                    hdi_min = TM_OUT$Err_Min_outlier,
                                                                                    hdi_max = TM_OUT$Err_Max_outlier,
                                                                                    tcol    = TM_OUT$TLight_outlier))
    
    
    plot_overview(paste(PIP$OutPath, out_str, "TM_false_correct.pdf", sep=""), list(x      = TM_OUT$TM_Index,
                                                                                   y       = TM_OUT$Mode_false_correct,
                                                                                   hdi_min = TM_OUT$Err_Min_false_correct,
                                                                                   hdi_max = TM_OUT$Err_Max_false_correct,
                                                                                   tcol    = TM_OUT$TLight_false_correct))
    
   
    plot_overview(paste(PIP$OutPath, out_str, "TM_false_defect.pdf", sep=""), list(x       = TM_OUT$TM_Index,
                                                                                   y       = TM_OUT$Mode_false_defect,
                                                                                   hdi_min = TM_OUT$Err_Min_false_defect,
                                                                                   hdi_max = TM_OUT$Err_Max_false_defect,
                                                                                   tcol    = TM_OUT$TLight_false_defect))
  }  
  return(list(BLR3_OUT=BLR3_OUT, BL_OUT=BL_OUT, B_OUT=B_OUT, Supp_OUT=Supp_OUT, R3TM_OUT=R3TM_OUT, TM_OUT=TM_OUT))
}