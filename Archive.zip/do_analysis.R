rm(list=ls())
STAN_Compile = 1

WORK_DIR <-"/data/Projects/HuaweiCDP/R3Model/"
setwd(WORK_DIR)
library("RJDBC")
library("rstan") 
library("msm")
library("data.table")

source("data_preparation.R")
source("small_helper.R")
source("post_process.R")
source("generate_output.R")

source("plot_checks.R")
source("test_functions.R")


rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
PIP <- list(
  OutPath        = paste(WORK_DIR, 'OutData/', sep=""),
  #-- STAN Parameter  
  STAN_Compile                   = STAN_Compile,
  STAN_Compile_NG                = STAN_Compile,
  STAN_MCMC_Steps                =          500,
  STAN_Chains                    =            4,
  ########################################################
  ## PARAMETERS WHICH HAVE TO BE SET !
  ########################################################
  log10_prob_diff_trunc          =    1.0,  # probability difference above which distribution is classified as not Gaussian
  Min_number_Data                =     10,  # Number of Measurements per BLR3 and R3TM below which data get ignored 
  TRUNC_percent                  =    0.8,  # percentage which gets cut away for Gauss fit 
  Critical_fail_material         =   0.02,  # At the moment Scalar, if changed to BLR3- "generate_output.R" has to be changed
  Critical_fail_TM               =   0.08,  # At the moment Scalar, if changed to BLR3- "generate_output.R" has to be changed
  Critical_fail_material_outlier =   0.05,  # At the moment Scalar, if changed to BLR3- "generate_output.R" has to be changed
  Critical_fail_TM_outlier       =   0.05,  # At the moment Scalar, if changed to BLR3- "generate_output.R" has to be changed
  prob_yellow                    =   0.65,  # At the moment Scalar
  prob_red                       =   0.90,  # At the moment Scalar
  ########################################################
  ## SYNTHETIC DATA PARAMETERS
  ########################################################
  Num_B                          =          2,
  Num_L_per_B                    =          3,
  Num_R3_per_L                   =          2,
  Num_TM_per_R3                  =          4,
  Num_Data_per_BLR3TM            =        200,
  # Material  and TM Parameter
  BLR3_mu                        = numeric(0), 
  BLR3_sd                        = numeric(0),  
  R3TM_mu                        = numeric(0),
  R3TM_sd                        = numeric(0), 
  ## not gaussian SYN Parameter
  Acc_min                        =         14,  # copied in an array [Num_R3] for Synthetic data -- FOR HANA Data this has to be an Array ALL R3 combinations
  Acc_max                        =       +Inf,  # as array [Num_R3] -- FOR ALL R3 combinations
  Unif_min                       =        -10,
  Unif_max                       =          0,
  BLR3_ng_rate                   = numeric(0),
  R3TM_ng_rate                   = numeric(0)
)

if(!file.exists(file.path(PIP$OutPath)))
{dir.create(PIP$OutPath, recursive = TRUE, mode = "0777")}

###-----------------------------------------------------------------------
### CREATE SYNTHETIC DATA ...
###-----------------------------------------------------------------------
tmp_NumBLR3      <- PIP$Num_B * PIP$Num_L_per_B * PIP$Num_R3_per_L
PIP$BLR3_mu      <- rnorm (tmp_NumBLR3, 20, 1) 
PIP$BLR3_sd      <- rgamma(tmp_NumBLR3, rate=  1 / 1^2, shape=1^2/1^2)
PIP$BLR3_ng_rate <- rbeta (tmp_NumBLR3, 5, 95)

tmp_Num_R3TM     <- PIP$Num_R3_per_L * PIP$Num_TM_per_R3
PIP$R3TM_mu      <- rnorm (tmp_Num_R3TM, 0, 2) 
PIP$R3TM_sd      <- rgamma(tmp_Num_R3TM, rate=  1 / 1^2, shape=1^2/1^2)
PIP$R3TM_ng_rate <- rbeta (tmp_Num_R3TM, 2, 98)
for(i in 1:PIP$Num_R3_per_L)
{
  i_min    <- ((i-1)*PIP$Num_TM_per_R3 + 2)
  i_max    <- (i*PIP$Num_TM_per_R3)
  i_target <-  (i-1)*PIP$Num_TM_per_R3 + 1
  index    <- seq(i_min, i_max, 1)
  mysum    <- sum(PIP$R3TM_mu[index])
  PIP$R3TM_mu[i_target] <- (-1)*mysum
} 
ReadData         <- create_quick_data(PIP)

###-----------------------------------------------------------------------
### SYNTHETIC DATA CREATION DONE
###-----------------------------------------------------------------------

###-----------------------------------------------------------------------
### Data preparation .....
###-----------------------------------------------------------------------
#ReadData   <- load_data()
Filter_Data <- filter_low_numbers(ReadData)
Trans_Data  <- transform_2_internal(Filter_Data)
Norm_Data   <- normalize_data(Trans_Data)
Trunc_Data  <- truncate_data (Norm_Data)

Sim   <- calc_SYN(PIP, Trunc_Data)

stan_keep  <- c("BLR3_mu", "BLR3_var","R3TM_mu", "R3TM_var")
if(PIP$STAN_Compile == "1")
{
    posterior <- stan(file     = "Model_Level03_v2.stan",
                    data       = Trunc_Data$stan_data,
                    iter       = PIP$STAN_MCMC_Steps,
                    chains     = PIP$STAN_Chains,
                    control    = list(adapt_delta=0.95), pars=stan_keep)
}else
{
    posterior <- stan(fit        = posterior,
                      data       = Trunc_Data$stan_data,
                      iter       = PIP$STAN_MCMC_Steps,
                      chains     = PIP$STAN_Chains,
                      control    = list(adapt_delta=0.95), pars=stan_keep)
}

#### ------------------
####   Postprocessing 
#### ------------------
posterior_ext     <- extract(posterior, inc_warmup = FALSE, pars=stan_keep)
check_results(posterior_ext, Trunc_Data, Norm_Data)

posterior_fails   <- calc_failures_with_integrals(posterior_ext, Norm_Data)
posterior_fails   <- calc_Hierarchy(posterior_fails, Trunc_Data)
posterior_outlier <- get_not_gauss_rate(posterior_ext, Norm_Data)
OUTDATA           <- generate_Output(posterior_fails, posterior_outlier, Norm_Data, out_str="")
