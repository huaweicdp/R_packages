
#-------------------------------------------------------------------------------------------
# TRUNCATED NORMAL CONV NORMAL
#-------------------------------------------------------------------------------------------
convolve_truncNormal <- function(v, X, Y) ### X ~ NORMAL Y ~ TRUNCATED NORMAL
{
  alpha   <-(Y$sigma^2*X$m + X$s^2*(v+X$m-Y$mu))/(Y$sigma^2 + X$s^2);
  beta_sq <- X$s^2*Y$sigma^2/(Y$sigma^2 + X$s^2);
  beta    <- sqrt(beta_sq);
  Phi_d   <- pnorm( (Y$mu-Y$lower)/Y$sigma, 0, 1)
  Phi_c   <- pnorm( (Y$mu-Y$upper)/Y$sigma, 0, 1)
  gamma   <- beta/(sqrt(2*pi)*X$s*Y$sigma*(Phi_d-Phi_c))
  
  trans_a <- pnorm((v+X$m-Y$lower-alpha)/beta, 0, 1)
  trans_b <- pnorm((v+X$m-Y$upper-alpha)/beta, 0, 1)
  
  return(gamma*(trans_a-trans_b) * exp(-0.5*(X$m - (v-Y$mu))^2/(X$s^2+Y$sigma^2) ) )
#  return(gamma*(trans_a-trans_b) * exp(-0.5*(X$m - (v+X$m-Y$mu))^2/(X$s^2+Y$sigma^2) ) )
}

convolve_truncNormal <- function(x)
{
  alpha   <-(PARA_TRUNCNORMAL$sigma^2*PARA_NORMAL$m + PARA_NORMAL$s^2*(x+PARA_NORMAL$m-PARA_TRUNCNORMAL$mu))/(PARA_TRUNCNORMAL$sigma^2 + PARA_NORMAL$s^2);
  beta_sq <- PARA_NORMAL$s^2*PARA_TRUNCNORMAL$sigma^2/(PARA_TRUNCNORMAL$sigma^2 + PARA_NORMAL$s^2);
  beta    <- sqrt(beta_sq);
  Phi_d   <- pnorm( (PARA_TRUNCNORMAL$mu-PARA_TRUNCNORMAL$lower)/PARA_TRUNCNORMAL$sigma, 0, 1)
  Phi_c   <- pnorm( (PARA_TRUNCNORMAL$mu-PARA_TRUNCNORMAL$upper)/PARA_TRUNCNORMAL$sigma, 0, 1)
  Phi_d_minus_Phi_c <- (Phi_d-Phi_c)
  if(Phi_d_minus_Phi_c < 1e-8)
    Phi_d_minus_Phi_c <- 1e-8
    
  gamma   <- beta/(sqrt(2*pi)*PARA_NORMAL$s*PARA_TRUNCNORMAL$sigma*Phi_d_minus_Phi_c)
  
  trans_a <- pnorm((x+PARA_NORMAL$m-PARA_TRUNCNORMAL$lower-alpha)/beta, 0, 1)
  trans_b <- pnorm((x+PARA_NORMAL$m-PARA_TRUNCNORMAL$upper-alpha)/beta, 0, 1)
  
  return(gamma*(trans_a-trans_b) * exp(-0.5*(PARA_NORMAL$m - (x-PARA_TRUNCNORMAL$mu))^2/(PARA_NORMAL$s^2+PARA_TRUNCNORMAL$sigma^2) ) )
#  return(gamma*(trans_a-trans_b) * exp(-0.5*(PARA_NORMAL$m - (x+PARA_NORMAL$m-PARA_TRUNCNORMAL$mu))^2/(PARA_NORMAL$s^2+PARA_TRUNCNORMAL$sigma^2) ) )
}

test_convolve_truncNormal <- function()
{
  
  Y <- list(mu=1, sigma=1.6, a=0.8, b=2.1)
  X      <- list(m=1, s=0.1)
  
  ### create synthetic
  library("msm")
  Num_data    <- 100000
  measurement <- rtnorm(Num_data, Y$mu, Y$sigma, lower=Y$a, upper= Y$b)
  noise       <- rnorm (Num_data, 0, X$s)
  
  x <- seq(-10,10,0.05)
  y <- convolve_truncNormal(x, X, Y)
  a <- hist(measurement+noise, freq=FALSE,breaks=30)
  lines(x,y, col="red")
}

#### -----------------------------------------------------------------------------------------####
#### Integrate truncated gauss etc
#### -----------------------------------------------------------------------------------------####
PARA_NORMAL      <-list()
PARA_TRUNCNORMAL <-list()
calc_failures_with_integrals<-function(InPosterior, InData)
{
  ### If FALSE calculated rates are in relation to all Mobiles, if TRUE R3TM_false_defect is in relation to all working mobiles and R3TM_false_correct is in relation to all non working mobiles
  BOOL_Correct <- FALSE
  stan_data    <- InData$stan_data 
  Num_samples  <- dim(InPosterior$BLR3_mu)[1]
  
  OutPosterior <- list( BLR3_theta         = array(0, dim=c(Num_samples, stan_data$Num_BLR3)),
                        R3TM_false_defect  = array(0, dim=c(Num_samples, stan_data$Num_R3TM)),
                        R3TM_false_correct = array(0, dim=c(Num_samples, stan_data$Num_R3TM)))

  ### --- Material failure rate 
  for(blr3 in 1:stan_data$Num_BLR3)
  {
    for(i in 1:Num_samples)
    {
      this_R3 <- stan_data$map_BLR3_2_R3[blr3]
      OutPosterior$BLR3_theta[i, blr3] <-   pnorm(InData$stan_data$Acc_min[this_R3], InPosterior$BLR3_mu[i, blr3], sqrt(InPosterior$BLR3_var[i, blr3])) +
                                        (1-pnorm(InData$stan_data$Acc_max[this_R3], InPosterior$BLR3_mu[i, blr3], sqrt(InPosterior$BLR3_var[i, blr3])))
    }
  }
    
  #### ---- Test machine failure rates
  corr_norm <- 1
  for(blr3tm in 1:stan_data$Num_BLR3TM)
  {
    this_blr3 <- stan_data$map_BLR3TM_2_BLR3[blr3tm]
    this_r3   <- stan_data$map_BLR3TM_2_R3  [blr3tm]  
    this_r3tm <- stan_data$map_BLR3TM_2_R3TM[blr3tm]
    for(i in 1:Num_samples)
    {
      ## failing rate of classifying a mobile wrongly as defect 
      PARA_TRUNCNORMAL <<- list (mu=InPosterior$BLR3_mu[i, this_blr3], sigma=sqrt(InPosterior$BLR3_var[i, this_blr3]), lower=InData$stan_data$Acc_min[this_r3], upper=InData$stan_data$Acc_max[this_r3])
      
      #if(BOOL_Correct)
        corr_norm <- 1 - OutPosterior$BLR3_theta[i, this_blr3]

      cat("blr3tm = ", blr3tm, "  i = ", i,"  calc : R3TM_false_defect\n")  
      if(InPosterior$R3TM_var[i, this_r3tm] != 0)
      {
        tmp_integral_low <- 0 
        tmp_integral_up  <- 0
        PARA_NORMAL  <<- list(m = InPosterior$R3TM_mu[i, this_r3tm], s=sqrt(InPosterior$R3TM_var[i, this_r3tm]))
        if(is.numeric(InData$stan_data$Acc_min[this_r3]) & !is.infinite(InData$stan_data$Acc_max[this_r3]))
          {tmp_integral_low  <- integrate(convolve_truncNormal, lower= -Inf, upper=InData$stan_data$Acc_min[this_r3], abs.tol =0.00001, stop.on.error=FALSE)$value}
        if(is.numeric(InData$stan_data$Acc_max[this_r3]) & !is.infinite(InData$stan_data$Acc_max[this_r3]))
          {tmp_integral_up   <- integrate(convolve_truncNormal, lower=InData$stan_data$Acc_max[this_r3], upper=+Inf, abs.tol =0.00001, stop.on.error=FALSE)$value}
        
        OutPosterior$R3TM_false_defect[i, this_r3tm] <- (tmp_integral_low + tmp_integral_up)*corr_norm
      }else
      {OutPosterior$R3TM_false_defect[i, this_r3tm]<- 0}

      cat("blr3tm = ", blr3tm, "  i = ", i,"  calc : R3TM_false_correct - left side\n")  
      ## failing rate of classifying a mobile wrongly as correct 
      ### CHANGE
      if(is.numeric(InData$stan_data$Acc_min[this_r3]) & !is.infinite(InData$stan_data$Acc_min[this_r3]))
      {
        cat(" para trunc : mu = ", InPosterior$BLR3_mu      [i, this_blr3],"\n")
        cat(" para trunc : sd = ", sqrt(InPosterior$BLR3_var[i, this_blr3]),"\n")
        cat(" para trunc : up = ", InData$stan_data$Acc_min [this_r3],"\n")
        PARA_TRUNCNORMAL <<- list(mu=InPosterior$BLR3_mu[i, this_blr3], sigma=sqrt(InPosterior$BLR3_var[i, this_blr3]), lower=-Inf, upper=InData$stan_data$Acc_min[this_r3])
        #if(BOOL_Correct)
          corr_norm  <- pnorm(InData$stan_data$Acc_min[this_r3], InPosterior$BLR3_mu[i, this_blr3], sqrt(InPosterior$BLR3_var[i, this_blr3]))
        
        if(InPosterior$R3TM_var[i, this_r3tm] != 0)
        {
          cat(" para norm : mu = ", InPosterior$R3TM_mu[i, this_r3tm],"\n")
          cat(" para norm : sd = ", sqrt(InPosterior$R3TM_var[i, this_r3tm]),"\n")
          cat(" para norm : bo = ", InData$stan_data$Acc_min[this_r3],"\n")
          cat(" para norm : up = ", InData$stan_data$Acc_max[this_r3],"\n")
          
          PARA_NORMAL      <- list(m = InPosterior$R3TM_mu[i, this_r3tm], s=sqrt(InPosterior$R3TM_var[i, this_r3tm]))
          
          tmp_integral_low <- integrate(convolve_truncNormal, lower= InData$stan_data$Acc_min[this_r3], upper=InData$stan_data$Acc_max[this_r3], abs.tol =0.00001, stop.on.error=FALSE)$value 
          OutPosterior$R3TM_false_correct[i, this_r3tm] <- tmp_integral_low * corr_norm
        }else
        {OutPosterior$R3TM_false_correct[i, this_r3tm]<- 0}
      }
      
      cat("blr3tm = ", blr3tm, "  i = ", i,"  calc : R3TM_false_correct - right side\n")  
      ## failing rate of classifying a mobile wrongly as correct 
      if(is.numeric(InData$stan_data$Acc_max[this_r3]) & !is.infinite(InData$stan_data$Acc_max[this_r3]))
      {
        PARA_TRUNCNORMAL <<- list (mu=InPosterior$BLR3_mu[i, this_blr3], sigma=sqrt(InPosterior$BLR3_var[i, this_blr3]), lower=InData$stan_data$Acc_max[this_r3], upper=Inf)
        #if(BOOL_Correct)
          corr_norm <- 1-pnorm(InData$stan_data$Acc_max[this_r3], InPosterior$BLR3_mu[i, this_blr3], sqrt(InPosterior$BLR3_var[i, this_blr3]))
      
        if(InPosterior$R3TM_var[i, this_r3tm] != 0)
        {
          PARA_NORMAL     <- list(m = InPosterior$R3TM_mu[i, this_r3tm], s=sqrt(InPosterior$R3TM_var[i, this_r3tm]))
          tmp_integral_up <- integrate(convolve_truncNormal, lower= InData$stan_data$Acc_min[this_r3], upper=InData$stan_data$Acc_max[this_r3], abs.tol =0.00001, stop.on.error=FALSE)$value 
          OutPosterior$R3TM_false_correct[i, this_r3tm] <- OutPosterior$R3TM_false_correct[i, this_r3tm] + tmp_integral_up * corr_norm
        }else
        {OutPosterior$R3TM_false_correct[i,this_r3tm]<- 0}
      }

      ### Normalisiation : NOT Commented out = relative to all defect   mobils -> much higher value
      ### Normalisiation :     Commented out = relative to all produced mobils
      if(BOOL_Correct)
        InPosterior$R3TM_false_correct[i, this_r3tm] <- InPosterior$R3TM_false_correct[i, this_r3tm]/InPosterior$BLR3_theta[i, this_blr3]
    } ### end for NumSamples
  }### end blr3tm
  return(OutPosterior)
}

#### -----------------------------------------------------------------------------------------####
#### get interval of deviations ....
#### -----------------------------------------------------------------------------------------####

##### CAREFUL InData has to be the not Truncated dataset!!!
get_not_gauss_rate <- function(InPosterior, InData)
{
  stan_data                     <- InData$stan_data
  Num_samples                   <- dim(InPosterior$BLR3_mu)[1]
  Num_Subsamples                <- 100
  subSample                     <- sample( x= seq(1, Num_samples, 1), size=Num_Subsamples, replace=FALSE ) 
  
  not_gauss_cnt_F   <- array(0, dim=c(Num_Subsamples, stan_data$Num_BLR3TM))
  not_gauss_cnt_T   <- array(0, dim=c(Num_Subsamples, stan_data$Num_BLR3TM))
  Num_Data                    <- array(0, dim=stan_data$Num_BLR3TM)
  for(blr3tm in 1:stan_data$Num_BLR3TM)
  {
    this_data        <- stan_data$Measurements[ which(stan_data$blr3tm_Index == blr3tm) ]
    Num_Data[blr3tm] <- length(this_data)
    this_num_data    <- length(this_data)
    data_x_inc       <- sort(this_data)
    data_x_dec       <- sort(this_data, decreasing=TRUE)
    
    this_blr3        <- stan_data$map_BLR3TM_2_BLR3[blr3tm]
    this_r3tm        <- stan_data$map_BLR3TM_2_R3TM[blr3tm] 
    this_r3          <- stan_data$map_BLR3TM_2_R3  [blr3tm]
    for( i in 1:length(subSample) )
    {
      this_blr3_mu   <- InPosterior$BLR3_mu [subSample[i], this_blr3]
      this_blr3_var  <- InPosterior$BLR3_var[subSample[i], this_blr3]
      
      this_r3tm_mu   <- InPosterior$R3TM_mu [subSample[i], this_r3tm]
      this_r3tm_var  <- InPosterior$R3TM_var[subSample[i], this_r3tm]
      
      this_conv_mu   <- this_blr3_mu + this_r3tm_mu 
      this_conv_sd   <- sqrt(this_blr3_var + this_r3tm_var)
      
      data_CDF       <- seq(1, this_num_data, 1)/this_num_data
      thisSample_CDF <- pnorm(data_x_inc, mean=this_conv_mu, sd=this_conv_sd)
      
      tmp            <- myrotate(cbind(log10(data_CDF), log10(thisSample_CDF)))
      Diff_vector    <- sqrt(tmp$y*tmp$y)
      this_x_min     <- numeric(0)
      if(length(which(Diff_vector > 1)) > 0)
        this_x_min        <- data_x_inc[max(which(Diff_vector > PIP$log10_prob_diff_trunc))]
      
      ##### now the max .....
      thisSample_CDF  <- 1-pnorm(data_x_dec, mean=this_conv_mu, sd=this_conv_sd)
      
      tmp             <- myrotate(cbind(log10(data_CDF), log10(thisSample_CDF)))
      Diff_vector     <- sqrt(tmp$y*tmp$y)
      this_x_max      <- numeric(0)
      if(length(which(Diff_vector > 1)) > 0)
        this_x_max    <- data_x_dec[max(which(Diff_vector > PIP$log10_prob_diff_trunc))]
      
      ##### calc rates from this :
      tmp_out_F <- 0
      tmp_out_T <- 0
      
      ## TODO ACC_Min max = NAN
      if(length(this_x_min)>0)
      {
        if(this_x_min < InData$stan_data$Acc_min[this_r3])
        {
          corr_norm <- pnorm(this_x_min, this_conv_mu, this_conv_sd)
          tmp_out_F   <- max(length(which(this_data<this_x_min)) - round(corr_norm*this_num_data), 0)
        }else
        {
          corr_norm <- pnorm(this_x_min, this_conv_mu, this_conv_sd) - pnorm(InData$stan_data$Acc_min[this_r3], this_conv_mu, this_conv_sd)
          tmp_out_T <- max(length(which( InData$stan_data$Acc_min[this_r3] < this_data & this_data < this_x_min)) - round(corr_norm*this_num_data), 0)
          
          corr_norm <- pnorm(InData$stan_data$Acc_min[this_r3], this_conv_mu, this_conv_sd)
          tmp_out_F <- max(length(which( this_data < InData$stan_data$Acc_min[this_r3])) - round(corr_norm*this_num_data), 0)
        }
      }
      
      if(length(this_x_max)>0)
      {
        if(InData$stan_data$Acc_max[this_r3] < this_x_max)
        {
          corr_norm <- 1-pnorm(this_x_max, this_conv_mu, this_conv_sd)
          tmp_out_F <- tmp_out_F + max(length(which(this_x_max <= this_data)) - round(corr_norm*this_num_data), 0)
        }else
        {
          corr_norm <- pnorm(InData$stan_data$Acc_max[this_r3], this_conv_mu, this_conv_sd) - pnorm(this_x_max, this_conv_mu, this_conv_sd)
          tmp_out_T <- max(length(which( this_x_max < this_data & this_data < InData$stan_data$Acc_max[this_r3])) - round(corr_norm*this_num_data), 0)
          
          corr_norm <- 1-pnorm(InData$stan_data$Acc_max[this_r3], this_conv_mu, this_conv_sd)
          tmp_out_F <- max(length(which( InData$stan_data$Acc_max[this_r3] < this_data )) - round(corr_norm*this_num_data), 0)
        }
      }
      not_gauss_cnt_F[i, blr3tm] <- tmp_out_F
      not_gauss_cnt_T[i, blr3tm] <- tmp_out_T
    }## end NumSamples
  }## end blr3tm
  #### ----------------------------------------------------------------------------------
  #### APPLY BAYESIAN MODEL TO measure nG rate   
  #### ----------------------------------------------------------------------------------
  
  nG_stan_data <- list(Num_Samples       = length(subSample),
                       Num_TM            = stan_data$Num_TM, 
                       Num_R3            = stan_data$Num_R3, 
                       Num_B             = stan_data$Num_B,
                       Num_BL            = stan_data$Num_BL,
                       Num_BR3           = stan_data$Num_BR3,
                       Num_BLR3          = stan_data$Num_BLR3,
                       Num_BLR3TM        = stan_data$Num_BLR3TM,
                       Num_R3TM          = stan_data$Num_R3TM,
                       map_br3_2_b       = stan_data$map_BR3_2_B,
                       map_br3_2_r3      = stan_data$map_BR3_2_R3,
                       map_blr3_2_bl     = stan_data$map_BLR3_2_BL,
                       map_blr3_2_br3    = stan_data$map_BLR3_2_BR3,
                       map_blr3tm_2_blr3 = stan_data$map_BLR3TM_2_BLR3,
                       map_blr3tm_2_r3tm = stan_data$map_BLR3TM_2_R3TM,
                       map_r3tm_2_tm     = stan_data$map_R3TM_2_TM,
                       Num_Outliers      = (not_gauss_cnt_F + not_gauss_cnt_T),
                       Num_Data          = Num_Data
                       )
  stan_keep <- c("BLR3_ng_theta", "BL_ng_theta", "B_ng_theta", "Supp_ng_theta", "R3TM_ng_theta", "TM_ng_theta")
  if(PIP$STAN_Compile_NG == "1")
  {
    posterior_nG <- stan(file    = "Model_nG_v2.stan",
                      data       = nG_stan_data,
                      iter       = PIP$STAN_MCMC_Steps,
                      chains     = PIP$STAN_Chains,
                      control    = list(adapt_delta=0.95),  pars=stan_keep)
    PIP$STAN_Compile_NG == "0"
  }else
  {
    posterior_nG <- stan(fit     = InPosterior$posterior_nG,
                      data       = nG_stan_data,
                      iter       = PIP$STAN_MCMC_Steps,
                      chains     = PIP$STAN_Chains,
                      control    = list(adapt_delta=0.95),  pars=stan_keep)
  }
  #### ----------------------------------------------------------------------------------
  #### APPLY BAYESIAN MODEL TO measure nG rate   
  #### ----------------------------------------------------------------------------------
  return(extract(posterior_nG, pars=stan_keep))
}  
#### -----------------------------------------------------------------------------------------####
#### add Hierarchy ....
#### -----------------------------------------------------------------------------------------####
calc_Hierarchy<-function (InPosterior, InData)
{
  stan_data <- InData$stan_data
  ### ---- Calculate weigths
  NumData        <- stan_data$Num_Data
  weight_lot     <- array(0,dim=stan_data$Num_BL) 
  weight_batch   <- array(0,dim=stan_data$Num_B) 
  
  for(bl in 1:stan_data$Num_BL)
  {
    blr3tm_index <- which(stan_data$map_BLR3TM_2_BL == bl)
    for(blr3tm in blr3tm_index)
    {
      tmp_i <- which( stan_data$blr3tm_Index == blr3tm)
      weight_lot[bl] <- weight_lot[bl] + length(tmp_i)
    }
    weight_batch[stan_data$map_BL_2_B[bl]] <- weight_batch[stan_data$map_BL_2_B[bl]] + weight_lot[bl]
  }
  
  for(bl in 1:stan_data$Num_BL)
  {weight_lot[bl] <- weight_lot[bl]/ weight_batch[stan_data$map_BL_2_B[bl]]}
      
  for(b in 1:stan_data$Num_B)
  {weight_batch[b] <- weight_batch[b]/NumData}
  
  ### -----------------------
  ### ADD MATERIAL HIERACHY
  ### -----------------------
  NumSamples <- dim(InPosterior$BLR3_theta)[1]
  InPosterior$BL_theta  <- array(1, dim=c(NumSamples, stan_data$Num_BL))
  InPosterior$B_theta   <- array(0, dim=c(NumSamples, stan_data$Num_B)) 
  InPosterior$Supp_theta<- array(0, dim=NumSamples) 
  InPosterior$TM_false_defect   <- array(1, dim=c(NumSamples, stan_data$Num_TM))
  InPosterior$TM_false_correct  <- array(1, dim=c(NumSamples, stan_data$Num_TM))
  
  for(i in 1:NumSamples)
  {
    for(blr3 in 1:stan_data$Num_BLR3)
    {InPosterior$BL_theta[i, stan_data$map_BLR3_2_BL[blr3]] = InPosterior$BL_theta[i, stan_data$map_BLR3_2_BL[blr3]] * (1 - InPosterior$BLR3_theta[i, blr3]);}
      
    for(bl in 1:stan_data$Num_BL)
    {
      InPosterior$BL_theta [i, bl]                         = 1.0 - InPosterior$BL_theta[i, bl];
      InPosterior$B_theta  [i, stan_data$map_BL_2_B[bl]]   = InPosterior$B_theta[i, stan_data$map_BL_2_B[bl]] + weight_lot[bl]*InPosterior$BL_theta[i, bl];
    }
      
    for(b in 1:stan_data$Num_B)
    {InPosterior$Supp_theta[i]  = InPosterior$Supp_theta[i] + weight_batch[b] * InPosterior$B_theta[i, b];}

        
    for(r3tm in 1:stan_data$Num_R3TM)
    {
      InPosterior$TM_false_defect [i, stan_data$map_R3TM_2_TM[r3tm]] = InPosterior$TM_false_defect [i, stan_data$map_R3TM_2_TM[r3tm]] * (1-InPosterior$R3TM_false_defect [i, r3tm]);
      InPosterior$TM_false_correct[i, stan_data$map_R3TM_2_TM[r3tm]] = InPosterior$TM_false_correct[i, stan_data$map_R3TM_2_TM[r3tm]] * (1-InPosterior$R3TM_false_correct[i, r3tm]);
    }
    
    for(tm in 1:stan_data$Num_TM)
    {
      InPosterior$TM_false_defect [i, tm] = 1.0 - InPosterior$TM_false_defect [i, tm]
      InPosterior$TM_false_correct[i, tm] = 1.0 - InPosterior$TM_false_correct[i, tm]
    }
  }
  return(InPosterior)
}
